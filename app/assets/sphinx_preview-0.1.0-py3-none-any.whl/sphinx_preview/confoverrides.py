"""Sphinx and Docutils settings management."""


from pathlib import Path
from typing import Any


def get_default_docutils_conf():
    # Secure Docutils usage - disable include and raw directives
    # See https://docutils.sourceforge.io/docs/howto/security.html#via-a-configuration-file
    return """[general]
file-insertion-enabled: off
raw-enabled: no"""


Confoverrides = dict[str, Any]


def get_default_confoverrides(user_confoverrides: Confoverrides):
    """Default conf.py overrides that must be applied to every project."""

    user_suppress_warnings: list = user_confoverrides.get("suppress_warnings", [])

    return {
        "extensions": ["sphinx_preview.ext", "myst_parser"],

        "html_theme": "preview",

        # Default RST domain is "py"
        "primary_domain": None,

        # Default highlighting is Python. Set "no highlighting".
        "highlight_language": "none",

        "exclude_patterns": ["_build", "Thumbs.db", ".DS_Store", ".documatt"],

        # System messages with problematic
        # If true, keep warnings as “system message” paragraphs in the built documents. Regardless of this setting, warnings are always written to the standard error stream when sphinx-build is run.
        # https://www.sphinx-doc.org/en/master/usage/configuration.html#confval-keep_warnings
        "keep_warnings": False,

        "suppress_warnings": user_suppress_warnings + [
            #  Supress strikethrough extension saying e.g.,
            #  index.md:5 WARNING: Strikethrough is currently only supported in HTML output [myst.strikethrough]
            "myst.strikethrough"
        ],

        # https://myst-parser.readthedocs.io/en/latest/syntax/optional.html
        "myst_enable_extensions": [
            # Inline and block atrributes
            "attrs_inline",
            "attrs_block",

            # allows ~~strikethrough~~
            # but it is supported only for HTML output
            # warning is suppressed above
            "strikethrough",

            # :Date: 2001-08-16
            # :Version: 1
            "fieldlist",

            # - [ ] An item that needs doing
            # - [x] An item that is complete
            "tasklist",

            # :::{note}
            # This text is **standard** _Markdown_
            # :::
            # instead
            # ```{note}
            # This text is **standard** _Markdown_
            # ```
            "colon_fence",

            # turn links in text to hyperlinks
            "linkify",
        ],

        # To only match URLs that start with schema, such as http://example.com
        "myst_linkify_fuzzy_links": False,

        # Auto-generated heading anchors
        # https://myst-parser.readthedocs.io/en/latest/syntax/optional.html#syntax-header-anchors
        "myst_heading_anchors": 6,
    }  # fmt: skip


def create_docutils_conf(where: str):
    Path(where, "docutils.conf").write_text(get_default_docutils_conf())


def merge_confoverrides(user_confoverrides: Confoverrides):
    """Merge theirs (user's) and ours conf.py settings. Ours takes precedence."""
    result = user_confoverrides.copy()
    merged = get_default_confoverrides(result)
    result.update(merged)
    return result