"""Fast HTML preview of Sphinx projects"""

from io import StringIO
import os
from pyodide.ffi import JsProxy
from sphinx.application import Sphinx
from strip_ansi import strip_ansi

from sphinx_preview.confoverrides import create_docutils_conf, merge_confoverrides, Confoverrides
from .ext.builder import PreviewBuilder
from typing import TypedDict

__version__ = "0.1.0"

class SphinxPreview:
    """Thin wrapper around Sphinx."""

    def __init__(
        self, srcdir: str, confdir: str, outdir: str, confoverrides: Confoverrides = {}, verbosity=0,
    ) -> None:
        """

        :param srcdir: _description_
        :param confdir: _description_
        :param outdir: _description_
        :param confoverrides: Extra conf.py options. Defaults to {}.
        :param verbosity: 0 = info (default), 1 = verbose, 2 = debug
        """

        # If called from JavaScript, convert to dict
        if isinstance(confoverrides, JsProxy):
            confoverrides = confoverrides.to_py()

        self.status = StringIO()
        self.warnings = StringIO()
        doctreedir = os.path.join(outdir, ".doctrees")

        create_docutils_conf(srcdir)

        app = Sphinx(
            srcdir=srcdir,
            confdir=confdir,
            outdir=outdir,
            doctreedir=str(doctreedir),
            buildername=PreviewBuilder.name,
            status=self.status,
            warning=self.warnings,
            confoverrides=merge_confoverrides(confoverrides),
            verbosity=verbosity
        )
        self.app = app

    class BuildResult(TypedDict):
        status: str
        warnings: str

    def build(self) -> BuildResult:
        self.app.build()
        return {
            "status": strip_ansi(self.status.getvalue()),
            "warnings": strip_ansi(self.warnings.getvalue()),
        }


