"""
Register theme with Sphinx.
"""

from pathlib import Path

from sphinx.application import Sphinx
from sphinx.util.typing import ExtensionMetadata

THEME_NAME = "preview"


def setup(app: Sphinx) -> ExtensionMetadata:
    """Setup the Sphinx application."""
    theme_path = str(Path(__file__).parent.resolve())
    app.add_html_theme(THEME_NAME, theme_path)

    app.config.html_theme = THEME_NAME

    return {"parallel_read_safe": True, "parallel_write_safe": True}