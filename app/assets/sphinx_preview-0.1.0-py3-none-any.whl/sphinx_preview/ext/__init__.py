"""Fast HTML preview extension"""

from sphinx.application import Sphinx
from sphinx.util.typing import ExtensionMetadata

from . import builder, warnings

__version__ = "0.1.0"


def setup(app: Sphinx) -> ExtensionMetadata:
    """
    Extension setup, called by Sphinx
    """
    builder.setup(app)
    warnings.setup(app)

    return {
        "version": __version__,
        "parallel_read_safe": True,
        "parallel_write_safe": True,
    }


