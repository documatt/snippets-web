"""
Silently collects all warnings emitted during build and write it as "warnings.json" at the end of the build in the output dir (e.g., `_build/html/warnings.json`).
"""

from pathlib import Path
from typing import TypedDict
from sphinx.application import Sphinx
from sphinx.util import logging as spx_logging
import logging as std_logging
import json

CONF_RELATIVE_LOCATION = True
"""Location will be relative to sources. Instead of `/Users/liborjelinek/git-dm/documatt-api/.my/aaa1/pok.md` only `pok.md`."""

CONF_FILENAME = "warnings.json"

logger = spx_logging.getLogger(__name__)


class Warning(TypedDict):
    """
    Warning records with location, lineno and msg.
    """

    location: str | None
    lineno: int | None
    msg: str


warnings: list[Warning] = []


class JsonWarningsHandler(std_logging.Handler):
    """Collect records."""

    def __init__(self, app: Sphinx, level=0) -> None:
        super().__init__(level)
        self.app = app

    def emit(self, record: spx_logging.SphinxLogRecord) -> None: # type: ignore
        location: str | None = None
        lineno: int | None = None

        # e.g., '/Users/liborjelinek/git-dm/documatt-api/.my/aaa1/index.md:28'
        # (record.location can be None)
        if record.location and ":" in record.location:
            splitted = record.location.split(":")
            location = splitted[0]
            # Sometimes location contains ":", but without number. E.g.,
            # '/Users/liborjelinek/git-dm/documatt-api/.my/aaa1/index.md:'
            # in this case, lineno is None
            maybe_lineno = splitted[1]
            if maybe_lineno.isdigit():
                lineno = int(maybe_lineno)
            else:
                lineno = None
        else:
            location = record.location

        # Instead of "/Users/liborjelinek/git-dm/documatt-api/.my/aaa1/pok.md"
        # only "pok.md"
        if location and CONF_RELATIVE_LOCATION:
            location = str(Path(location).relative_to(self.app.srcdir))

        # e.g., 'Unknown interpreted text role "suba". [myst.role_unknown]'
        msg = JsonWarningsHandler._getMessage(record)
        # cannot use record.getMessage() because SphinxLogRecord overrides it
        # and returns '{location}: {self.prefix}{message}' instead.

        # Collect only if not already collected
        warning: Warning = {"location": location, "lineno": lineno, "msg": msg}
        if warning not in warnings:
            warnings.append(warning)

    @staticmethod
    def _getMessage(record: spx_logging.SphinxLogRecord):
        """
        Return the message for this LogRecord.

        Return the message for this LogRecord after merging any user-supplied
        arguments with the message.
        """
        # copy-paste of standard logging LogRecord.getMessage()
        msg = str(record.msg)
        if record.args:
            msg = msg % record.args
        return msg


def build_finished_handler(app: Sphinx, exception: Exception | None):
    """Write collected warnings as JSON"""
    filename = CONF_FILENAME

    logger.info(f"Collected {len(warnings)} warnings and serializing to {filename}")

    warnings_json = Path(app.outdir, filename)
    warnings_json.write_text(json.dumps(warnings))


def setup(app: Sphinx):
    # Don't show [warning_types] after warning message. E.g.,
    # /Users/liborjelinek/git-dm/snippets-next/sphinx-preview/tests/data/srcdir/index.rst:9: WARNING: Literal block expected; none found. [docutils] [docutils] [docutils]
    # It's true since 8.0.0 (https://www.sphinx-doc.org/en/master/usage/configuration.html#confval-show_warning_types)
    app.config.show_warning_types = False

    # Registration done the same as WarningStreamHandler in
    # setup() from sphinx.logging
    logger = std_logging.getLogger(spx_logging.NAMESPACE)
    struct_handler = JsonWarningsHandler(app)
    struct_handler.addFilter(spx_logging.WarningSuppressor(app))
    struct_handler.addFilter(spx_logging.WarningLogRecordTranslator(app))
    struct_handler.addFilter(spx_logging.OnceFilter())
    struct_handler.setLevel(std_logging.WARNING)
    logger.addHandler(struct_handler)

    app.connect("build-finished", build_finished_handler)