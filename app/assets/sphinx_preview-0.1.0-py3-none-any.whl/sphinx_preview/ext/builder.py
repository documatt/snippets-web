from sphinx.application import Sphinx
from sphinx.builders.html import StandaloneHTMLBuilder
from sphinx.environment import BuildEnvironment


class PreviewBuilder(StandaloneHTMLBuilder):
    """
    Builder omitting building search index
    """

    name = "preview"

    # Don't generate search.html and searchindex.js in root
    search = False

    def __init__(self, app: Sphinx, env: BuildEnvironment) -> None:
        super().__init__(app, env)

    # Don't generate .buildinfo
    def write_buildinfo(self) -> None:
        pass

    # Don't generate objects.inv
    def dump_inventory(self) -> None:
        pass


def setup(app: Sphinx):
    # Register preview builder
    app.add_builder(PreviewBuilder)

    # Don't generate files in _sources/
    app.config.html_copy_source = False

    # Don't generate genindex.html
    app.config.html_use_index = False